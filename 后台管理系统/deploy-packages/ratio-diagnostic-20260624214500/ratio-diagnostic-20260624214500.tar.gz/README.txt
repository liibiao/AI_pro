ratio diagnostic
