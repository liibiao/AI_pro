marker check
