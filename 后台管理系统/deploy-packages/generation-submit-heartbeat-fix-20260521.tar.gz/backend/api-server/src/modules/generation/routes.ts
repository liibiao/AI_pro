import { Prisma, type GenerationRefundSource, type ModelType } from '@prisma/client';
import { Router, type Request } from 'express';
import { z } from 'zod';
import { applyWalletDelta, assertEnoughBalance, calculateCreditsForUser, estimateTextTokens } from '../../billing.js';
import { config } from '../../config.js';
import { prisma } from '../../db.js';
import { fail, ok, routeParam } from '../../http.js';
import { asyncHandler, requireAuth, requireRole } from '../../middleware.js';
import { adminRoles } from '../../types.js';
import { getGenerationRuntimeSettings } from '../system-settings/service.js';
import { generatedImageFilePath, getGenerationAdapter, materializeImageResultUrl } from './adapters/registry.js';

const router = Router();
type RuntimeGenerationTask = Prisma.GenerationTaskGetPayload<{ include: { provider: true; model: true } }>;
type ImmediateImageSubmitResult = {
  status: 'RUNNING' | 'SUCCESS' | 'FAILED';
  progress?: number;
  upstreamTaskId?: string;
  upstreamRequestId?: string;
  requestJson: Prisma.InputJsonValue;
  responseJson: Prisma.InputJsonValue;
  resultJson?: Prisma.InputJsonValue;
  resultUrls?: string[];
  errorCode?: string;
  errorMessage?: string;
};
let generationReconcilerTimer: ReturnType<typeof setInterval> | null = null;

const taskSchema = z.object({
  channelKey: z.string().min(1),
  modelId: z.string().min(1),
  type: z.enum(['IMAGE', 'VIDEO', 'LLM']),
  mode: z.string().min(1),
  prompt: z.string().min(1),
  negativePrompt: z.string().optional(),
  inputFiles: z.array(z.unknown()).default([]),
  params: z.record(z.unknown()).default({}),
  clientRequestId: z.string().trim().min(1).max(160).optional(),
});

router.get('/results/:name', asyncHandler(async (req, res) => {
  const filePath = generatedImageFilePath(routeParam(req.params.name));
  if (!filePath) fail(404, '图片不存在', 'GENERATED_IMAGE_NOT_FOUND');
  res.setHeader('Cache-Control', 'public, max-age=86400');
  res.sendFile(filePath, err => {
    if (err && !res.headersSent) res.status(404).json({ ok: false, error: '图片不存在', code: 'GENERATED_IMAGE_NOT_FOUND' });
  });
}));

router.post('/tasks', requireAuth, asyncHandler(async (req, res) => {
  const body = taskSchema.parse(req.body);
  const clientRequestId = resolveClientRequestId(req, body);
  if (clientRequestId) {
    const existing = await findIdempotentTask(req.user!.id, clientRequestId);
    if (existing) {
      ok(res, { task: existing, chargedCredits: existing.chargedCredits, idempotent: true });
      return;
    }
  }
  const { provider, model } = await getProviderAndModel(body.channelKey, body.modelId, body.type);
  const costInput = estimateTaskCostInput(body);
  const cost = await calculateCreditsForUser(prisma, req.user!.id, model, costInput);
  await assertEnoughBalance(prisma, req.user!.id, cost.chargedCredits);

  let task;
  try {
    task = await prisma.generationTask.create({
      data: {
        userId: req.user!.id,
        clientRequestId,
        providerId: provider.id,
        modelId: model.id,
        channelKey: provider.providerKey,
        type: body.type,
        mode: body.mode,
        status: 'PENDING',
        prompt: body.prompt,
        negativePrompt: body.negativePrompt,
        inputFilesJson: body.inputFiles as Prisma.InputJsonValue,
        paramsJson: body.params as Prisma.InputJsonValue,
        chargedCredits: 0,
        costAmount: 0,
        costUsd: new Prisma.Decimal(0),
      },
    });
  } catch (err) {
    const existing = clientRequestId ? await recoverIdempotentCreate(req.user!.id, clientRequestId, err) : null;
    if (existing) {
      ok(res, { task: existing, chargedCredits: existing.chargedCredits, idempotent: true });
      return;
    }
    throw err;
  }

  const startedAt = Date.now();
  await markGenerationSubmitStarted(task.id, task.createdAt);
  const stopSubmitHeartbeat = startGenerationSubmitHeartbeat(task.id);
  try {
    const runtime = await getGenerationRuntimeSettings();
    const adapter = getGenerationAdapter(resolveGenerationAdapterName(provider, model));
    let submit = await adapter.submit({
      provider,
      model,
      type: body.type,
      mode: body.mode,
      prompt: body.prompt,
      negativePrompt: body.negativePrompt,
      inputFiles: body.inputFiles,
      params: body.params,
      timeoutMs: resolveGenerationTimeoutMs(body.type, provider.timeoutMs, runtime.upstreamTimeoutMs),
    });
    if (body.type === 'IMAGE') {
      submit = await materializeImmediateImageSubmitResults(provider, submit);
    }
    const hasDirectResults = (submit.resultUrls || []).length > 0;
    const missingPollTarget = submit.status === 'RUNNING' && !submit.upstreamTaskId && !hasDirectResults;
    const status = submit.status === 'SUCCESS' || (submit.status === 'RUNNING' && !submit.upstreamTaskId && hasDirectResults)
      ? 'SUCCESS'
      : submit.status === 'FAILED' || missingPollTarget ? 'FAILED' : 'RUNNING';
    const billableCredits = status === 'FAILED' ? 0 : cost.chargedCredits;
    const updated = await prisma.$transaction(async tx => {
      const generationTask = await tx.generationTask.update({
        where: { id: task.id },
        data: {
          status,
          chargedCredits: billableCredits,
          costAmount: status === 'FAILED' ? 0 : cost.costAmount,
          costUsd: new Prisma.Decimal(status === 'FAILED' ? 0 : cost.costUsd),
          progress: submit.progress ?? (status === 'SUCCESS' ? 100 : 0),
          requestJson: submit.requestJson,
          responseJson: submit.responseJson,
          upstreamTaskId: submit.upstreamTaskId,
          upstreamRequestId: submit.upstreamRequestId,
          resultJson: submit.resultJson,
          resultUrlsJson: submit.resultUrls as Prisma.InputJsonValue,
          errorCode: status === 'FAILED' ? submit.errorCode || (missingPollTarget ? 'UPSTREAM_TASK_ID_MISSING' : undefined) : null,
          errorMessage: status === 'FAILED' ? submit.errorMessage || (missingPollTarget ? '上游响应没有返回任务 ID 或结果 URL，无法继续轮询' : undefined) : null,
          startedAt: task.createdAt,
          completedAt: status === 'SUCCESS' ? new Date() : undefined,
          failedAt: status === 'FAILED' ? new Date() : null,
        },
      });
      let balance: number | undefined;
      if (billableCredits > 0) {
        const walletChange = await applyWalletDelta(tx, { userId: req.user!.id, delta: -billableCredits, requireNonNegative: true });
        balance = walletChange.balanceAfter;
        await tx.walletLog.create({
          data: {
            userId: req.user!.id,
            type: 'CONSUME',
            amount: -billableCredits,
            balanceBefore: walletChange.balanceBefore,
            balanceAfter: walletChange.balanceAfter,
            relatedType: 'GENERATION_TASK',
            relatedId: task.id,
            remark: `${model.displayName} 生成任务预扣`,
          },
        });
      }
      await tx.providerHealthLog.create({
        data: {
          providerId: provider.id,
          modelId: model.id,
          taskId: task.id,
          status,
          latencyMs: Date.now() - startedAt,
          errorCode: submit.errorCode,
          errorMessage: submit.errorMessage,
        },
      });
      return { generationTask, balance };
    });
    ok(res, { task: updated.generationTask, balance: updated.balance, chargedCredits: billableCredits });
  } catch (err) {
    const adapterName = resolveGenerationAdapterName(provider, model);
    const baseMessage = err instanceof Error ? err.message : String(err);
    const message = `${baseMessage} [generation-route channel=${provider.providerKey} requestedModelId=${body.modelId} dbModel=${model.id}/${model.name}/${model.type} adapter=${adapterName}]`;
    const failedTask = await prisma.generationTask.update({
      where: { id: task.id },
      data: {
        status: 'FAILED',
        chargedCredits: 0,
        costAmount: 0,
        costUsd: new Prisma.Decimal(0),
        errorCode: 'GENERATION_SUBMIT_FAILED',
        errorMessage: message,
        failedAt: new Date(),
      },
    });
    await prisma.providerHealthLog.create({
      data: { providerId: provider.id, modelId: model.id, taskId: task.id, status: 'FAILED', latencyMs: Date.now() - startedAt, errorMessage: message },
    }).catch(() => undefined);
    ok(res, { task: failedTask, chargedCredits: 0 });
  } finally {
    stopSubmitHeartbeat();
  }
}));

router.get('/tasks', requireAuth, asyncHandler(async (req, res) => {
  const take = Math.min(Math.max(Number(req.query.limit || 100), 1), 300);
  const tasks = await prisma.generationTask.findMany({
    where: { userId: req.user!.id },
    include: { model: { select: { id: true, displayName: true, name: true, type: true } }, provider: { select: { id: true, providerKey: true, name: true } } },
    orderBy: { createdAt: 'desc' },
    take,
  });
  ok(res, { items: tasks });
}));

router.get('/tasks/:id', requireAuth, asyncHandler(async (req, res) => {
  const task = await prisma.generationTask.findFirst({
    where: { id: routeParam(req.params.id), userId: req.user!.id },
    include: { model: { select: { id: true, displayName: true, name: true, type: true } }, provider: { select: { id: true, providerKey: true, name: true } } },
  });
  if (!task) fail(404, '生成任务不存在', 'GENERATION_TASK_NOT_FOUND');
  ok(res, { task });
}));

router.post('/tasks/:id/query', requireAuth, asyncHandler(async (req, res) => {
  const task = await prisma.generationTask.findFirst({
    where: { id: routeParam(req.params.id), userId: req.user!.id },
    include: { provider: true, model: true },
  });
  if (!task) fail(404, '生成任务不存在', 'GENERATION_TASK_NOT_FOUND');
  const result = await queryAndUpdateGenerationTask(task);
  ok(res, result);
}));

router.get('/admin/tasks', requireAuth, requireRole(adminRoles), asyncHandler(async (req, res) => {
  const take = Math.min(Math.max(Number(req.query.limit || 200), 1), 500);
  const status = String(req.query.status || '').trim();
  const channelKey = String(req.query.channelKey || '').trim();
  const userId = String(req.query.userId || '').trim();
  const type = String(req.query.type || '').trim();
  const mode = String(req.query.mode || '').trim();
  const wantsStoryboard = isStoryboardModeQuery(mode);
  const where: Prisma.GenerationTaskWhereInput = {};
  if (status) where.status = status as any;
  if (channelKey) where.channelKey = channelKey;
  if (userId) where.userId = userId;
  if (type) where.type = type as ModelType;
  if (mode && !wantsStoryboard) where.mode = { contains: mode, mode: 'insensitive' };
  const tasks = await prisma.generationTask.findMany({
    where,
    include: { user: { select: { id: true, nickname: true, phone: true } }, model: true, provider: { select: { id: true, providerKey: true, name: true } }, refunds: true },
    orderBy: { createdAt: 'desc' },
    take,
  });
  ok(res, { items: wantsStoryboard ? tasks.filter(isStoryboardGenerationTask) : tasks });
}));

const refundSchema = z.object({
  reason: z.string().optional(),
});

router.post('/admin/tasks/:id/refund', requireAuth, requireRole(adminRoles), asyncHandler(async (req, res) => {
  const body = refundSchema.parse(req.body || {});
  const refund = await prisma.$transaction(tx => refundGenerationTask(tx, {
    taskId: routeParam(req.params.id),
    source: 'ADMIN',
    operatorId: req.user!.id,
    reason: body.reason || '后台人工退款',
  }));
  ok(res, refund);
}));

export function startGenerationTaskReconciler() {
  if (!config.generationReconcileEnabled || generationReconcilerTimer) return;
  const intervalMs = Math.max(10_000, config.generationReconcileIntervalMs);
  const run = () => {
    reconcileStaleGenerationTasks().catch(err => {
      console.warn('[generation-reconciler] failed:', err instanceof Error ? err.message : err);
    });
  };
  generationReconcilerTimer = setInterval(run, intervalMs);
  generationReconcilerTimer.unref?.();
  const firstRun = setTimeout(run, Math.min(5000, intervalMs));
  firstRun.unref?.();
}

export async function reconcileStaleGenerationTasks() {
  const staleMinutes = Math.max(1, config.generationStaleTaskMinutes);
  const staleBefore = new Date(Date.now() - staleMinutes * 60_000);
  const tasks = await prisma.generationTask.findMany({
    where: {
      status: { in: ['CREATED', 'PENDING', 'RUNNING'] },
      updatedAt: { lt: staleBefore },
    },
    include: { provider: true, model: true },
    orderBy: { updatedAt: 'asc' },
    take: 25,
  });

  let queried = 0;
  let closed = 0;
  let refunded = 0;

  for (const task of tasks) {
    try {
      if (task.upstreamTaskId) {
        queried += 1;
        const result = await queryAndUpdateGenerationTask(task);
        if (result.refund?.refundedCredits) refunded += Number(result.refund.refundedCredits || 0);
        continue;
      }
      const result = await closeInterruptedGenerationTask(task);
      closed += 1;
      if (result.refund?.refundedCredits) refunded += Number(result.refund.refundedCredits || 0);
    } catch (err) {
      console.warn(`[generation-reconciler] task ${task.id} skipped:`, err instanceof Error ? err.message : err);
    }
  }

  return { checked: tasks.length, queried, closed, refunded };
}

async function getProviderAndModel(channelKey: string, modelId: string, type: ModelType) {
  const provider = await prisma.upstreamProvider.findUnique({ where: { providerKey: channelKey }, include: { models: true } });
  if (!provider) fail(404, `渠道不可用：找不到 channelKey=${channelKey || '-'}，modelId=${modelId || '-'}，type=${type}`, 'PROVIDER_NOT_FOUND');
  if (provider.status !== 'ACTIVE') fail(404, `渠道不可用：channelKey=${channelKey || '-'} 当前状态为 ${provider.status}，modelId=${modelId || '-'}，type=${type}`, 'PROVIDER_DISABLED');
  const candidates = provider.models.filter(item => item.status === 'ACTIVE' && item.type === type);
  const model = candidates.find(item => item.id === modelId)
    || candidates.find(item => item.modelKey === modelId)
    || candidates.find(item => item.name === modelId);
  if (!model) fail(404, `模型不可用：channelKey=${channelKey || '-'} 下找不到 ACTIVE ${type} 模型 modelId=${modelId || '-'}`, 'MODEL_NOT_FOUND');
  return { provider, model };
}

function resolveGenerationAdapterName(provider: { adapter?: string | null; providerKey?: string | null; name?: string | null }, model: { adapter?: string | null; name?: string | null; displayName?: string | null; modelKey?: string | null }) {
  const configured = String(model.adapter || provider.adapter || '').trim();
  const configuredLower = configured.toLowerCase();
  const modelHint = [
    provider.providerKey,
    provider.name,
    model.modelKey,
    model.name,
    model.displayName,
  ].join(' ').toLowerCase();
  const hint = [
    provider.providerKey,
    provider.name,
    model.modelKey,
    model.name,
    model.displayName,
    configured,
  ].join(' ').toLowerCase();
  if (hint.includes('seedance2.0-vip') || hint.includes('seedance2-vip') || hint.includes('seedance 2.0 vip')) return 'seedance2-vip';
  if (configuredLower === 'seedance2-vip' || configuredLower === 'seedance2.0-vip') return 'seedance2-vip';
  if (['gemini-image-generate', 'gemini-image-edit', 'gemini-video', 'veo-video', 'gemini-chat', 'gemini-llm', 'veo-chat', 'veo-3.1', 'grok-video', 'grok-image', 'grok-image-edit', 'grok-chat', 'grok-llm'].includes(configuredLower)) return configuredLower;
  if (hint.includes('gpt-image-v2') || hint.includes('gpt image v2') || hint.includes('gpt-image- v2')) return 'gpt-image-v2';
  if (modelHint.includes('sora-v3') || modelHint.includes('sora v3') || modelHint.includes('sora-2') || modelHint.includes('sora 2')) return 'sora-video';
  if (configuredLower === 'sora-video' || configuredLower === 'notevideo') return 'sora-video';
  if (configuredLower === 'gemini-image') return 'gemini-image';
  if (hint.includes('gemini') && hint.includes('image') && (hint.includes('edit') || hint.includes('图生图'))) return 'gemini-image-edit';
  if (hint.includes('gemini') && hint.includes('image') && (hint.includes('unified') || hint.includes('统一') || hint.includes('/images/generations'))) return 'gemini-image-generate';
  if (hint.includes('gemini') && hint.includes('image')) return 'gemini-image';
  if (hint.includes('grok-imagine') && hint.includes('video')) return 'grok-video';
  if (hint.includes('grok-imagine') && (hint.includes('edit') || configuredLower === 'grok-image-edit')) return 'grok-image-edit';
  if (hint.includes('grok-imagine')) return 'grok-image';
  if (hint.includes('grok-4') || configuredLower === 'grok-chat' || configuredLower === 'grok-llm') return 'grok-chat';
  if (hint.includes('gemini-') || configuredLower === 'gemini-chat' || configuredLower === 'gemini-llm') return 'gemini-chat';
  if (hint.includes('veo-3.1') || hint.includes('veo 3.1') || configuredLower === 'veo-chat' || configuredLower === 'veo-3.1') return 'veo-chat';
  if (hint.includes('veo-') || configuredLower === 'gemini-video' || configuredLower === 'veo-video') return 'gemini-video';
  return configuredLower || configured;
}

function resolveUpstreamTimeoutMs(providerTimeoutMs: number | null | undefined, runtimeTimeoutMs: number) {
  return Math.max(Number(providerTimeoutMs || 0), Number(runtimeTimeoutMs || 0), 600000);
}

function resolveGenerationTimeoutMs(type: ModelType, providerTimeoutMs: number | null | undefined, runtimeTimeoutMs: number) {
  if (type === 'IMAGE' || type === 'VIDEO') return 0;
  return resolveUpstreamTimeoutMs(providerTimeoutMs, runtimeTimeoutMs);
}

function resolveClientRequestId(req: Request, body: z.infer<typeof taskSchema>) {
  return normalizeClientRequestId(
    body.clientRequestId ||
    req.get('Idempotency-Key') ||
    req.get('X-Idempotency-Key') ||
    body.params.clientRequestId ||
    body.params.requestId,
  );
}

function isStoryboardModeQuery(mode: string) {
  return /storyboard|故事板|分镜|panel|comic/i.test(String(mode || ''));
}

function isStoryboardGenerationTask(task: { mode?: unknown; prompt?: unknown; paramsJson?: unknown }) {
  const params = isRecord(task.paramsJson) ? task.paramsJson : {};
  const text = [
    task.mode,
    params.mode,
    params.taskType,
    params.template,
    params.sourceNodeType,
    task.prompt,
    JSON.stringify(params),
  ].filter(Boolean).join(' ').toLowerCase();
  return /storyboard|故事板|分镜|panel|comic/.test(text);
}

function normalizeClientRequestId(value: unknown) {
  const text = String(value || '').trim();
  return text ? text.slice(0, 160) : null;
}

async function findIdempotentTask(userId: string, clientRequestId: string) {
  return prisma.generationTask.findFirst({
    where: { userId, clientRequestId },
    include: { model: { select: { id: true, displayName: true, name: true, type: true } }, provider: { select: { id: true, providerKey: true, name: true } } },
  });
}

async function recoverIdempotentCreate(userId: string, clientRequestId: string, err: unknown) {
  if (!(err instanceof Prisma.PrismaClientKnownRequestError) || err.code !== 'P2002') return null;
  return findIdempotentTask(userId, clientRequestId);
}

async function queryAndUpdateGenerationTask(task: RuntimeGenerationTask) {
  if (isTerminalStatus(task.status) && task.status === 'SUCCESS') {
    const completed = await completeTaskFromStoredResultUrls(task);
    if (completed) return { task: completed };
    return { task };
  }
  if (isTerminalStatus(task.status) && task.status !== 'SUCCESS') {
    const completed = await completeTaskFromStoredResultUrls(task);
    if (completed) return { task: completed };
  }
  if (isTerminalStatus(task.status)) return { task };
  if (!task.upstreamTaskId) {
    const completed = await completeTaskFromStoredResultUrls(task);
    if (completed) return { task: completed };
    if (isFreshGenerationSubmit(task)) return { task };
    return closeInterruptedGenerationTask(task, '任务提交中断：后台没有收到上游任务 ID 或同步生成结果，请重新生成');
  }
  const adapter = getGenerationAdapter(resolveGenerationAdapterName(task.provider, task.model));
  if (!adapter.query) fail(400, '当前渠道不支持查询', 'ADAPTER_QUERY_NOT_SUPPORTED');
  const runtime = await getGenerationRuntimeSettings();
  let result;
  try {
    result = await adapter.query({
      provider: task.provider,
      model: task.model,
      type: task.type,
      mode: task.mode,
      prompt: task.prompt,
      negativePrompt: task.negativePrompt || undefined,
      inputFiles: Array.isArray(task.inputFilesJson) ? task.inputFilesJson : [],
      params: isRecord(task.paramsJson) ? task.paramsJson : {},
      timeoutMs: resolveGenerationTimeoutMs(task.type, task.provider.timeoutMs, runtime.upstreamTimeoutMs),
      upstreamTaskId: task.upstreamTaskId,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    if (!isTransientGenerationFailureMessage(message)) throw err;
    const updated = await prisma.generationTask.update({
      where: { id: task.id },
      data: {
        status: 'FAILED',
        errorCode: 'GENERATION_QUERY_FAILED',
        errorMessage: message,
        failedAt: new Date(),
      },
      include: { provider: true, model: true },
    });
    const refund = updated.chargedCredits > 0
      ? await prisma.$transaction(tx => refundGenerationTask(tx, {
        taskId: updated.id,
        source: 'AUTO',
        reason: message || '上游任务查询失败，已自动退款',
      }))
      : null;
    return { task: refund?.task || updated, ...(refund ? { refund } : {}) };
  }
  const status = result.status === 'SUCCESS' ? 'SUCCESS' : result.status === 'FAILED' ? 'FAILED' : 'RUNNING';
  const updated = await prisma.generationTask.update({
    where: { id: task.id },
    data: {
      status,
      progress: result.progress ?? task.progress,
      responseJson: result.responseJson,
      resultJson: result.resultJson,
      resultUrlsJson: result.resultUrls as Prisma.InputJsonValue,
      errorCode: result.errorCode,
      errorMessage: result.errorMessage,
      completedAt: status === 'SUCCESS' ? new Date() : undefined,
      failedAt: status === 'FAILED' ? new Date() : undefined,
    },
    include: { provider: true, model: true },
  });
  const refund = status === 'FAILED'
    ? await prisma.$transaction(tx => refundGenerationTask(tx, {
      taskId: updated.id,
      source: 'AUTO',
      reason: result.errorMessage || '上游任务失败，已自动退款',
    }))
    : null;
  return { task: refund?.task || updated, ...(refund ? { refund } : {}) };
}

async function closeInterruptedGenerationTask(task: RuntimeGenerationTask, reason = '任务提交中断，后台自动关闭') {
  const completed = await completeTaskFromStoredResultUrls(task);
  if (completed) return { task: completed };
  const updated = await prisma.generationTask.update({
    where: { id: task.id },
    data: {
      status: 'FAILED',
      errorCode: 'GENERATION_TASK_INTERRUPTED',
      errorMessage: reason,
      failedAt: new Date(),
    },
    include: { provider: true, model: true },
  });
  const refund = updated.chargedCredits > 0
    ? await prisma.$transaction(tx => refundGenerationTask(tx, {
      taskId: updated.id,
      source: 'AUTO',
      reason,
    }))
    : null;
  return { task: refund?.task || updated, ...(refund ? { refund } : {}) };
}

async function completeTaskFromStoredResultUrls(task: RuntimeGenerationTask) {
  const urls = await materializeStoredGenerationResultUrls(task, collectStoredGenerationResultUrls(task));
  if (!urls.length) return null;
  const resultJson = normalizeStoredGenerationResultJson(task.resultJson, urls);
  return prisma.generationTask.update({
    where: { id: task.id },
    data: {
      status: 'SUCCESS',
      progress: 100,
      resultUrlsJson: urls as Prisma.InputJsonValue,
      resultJson,
      errorCode: null,
      errorMessage: null,
      completedAt: task.completedAt || new Date(),
      failedAt: null,
    },
    include: { provider: true, model: true },
  });
}

async function materializeStoredGenerationResultUrls(task: RuntimeGenerationTask, urls: string[]) {
  if (task.type !== 'IMAGE') return urls;
  const resolved: string[] = [];
  for (const url of urls) {
    const materialized = await materializeImageResultUrl(task.provider, url).catch(() => '');
    const next = materialized || url;
    if (next && !resolved.includes(next)) resolved.push(next);
  }
  return resolved;
}

async function materializeImmediateImageSubmitResults(
  provider: RuntimeGenerationTask['provider'],
  submit: ImmediateImageSubmitResult,
) {
  const urls = await materializeStoredGenerationResultUrls(
    { type: 'IMAGE', provider } as RuntimeGenerationTask,
    collectStoredGenerationResultUrls({
      resultUrlsJson: submit.resultUrls,
      resultJson: submit.resultJson,
      responseJson: submit.responseJson,
    }),
  );
  if (!urls.length) return submit;
  return {
    ...submit,
    resultUrls: urls,
    resultJson: normalizeStoredGenerationResultJson(submit.resultJson, urls),
  };
}

function normalizeStoredGenerationResultJson(resultJson: unknown, urls: string[]) {
  if (isRecord(resultJson) && Object.keys(resultJson).length) {
    return {
      ...resultJson,
      url: urls[0],
      outputs: urls,
    } as Prisma.InputJsonValue;
  }
  return { url: urls[0], outputs: urls } as Prisma.InputJsonValue;
}

function collectStoredGenerationResultUrls(task: { resultUrlsJson?: unknown; resultJson?: unknown; responseJson?: unknown }) {
  const urls: string[] = [];
  const push = (value: unknown) => {
    const raw = String(value || '').trim();
    if (!raw) return;
    if (!/^https?:\/\//i.test(raw) && !/^\/api\/generation\/results\//i.test(raw) && !/^\/v1\/(?:images\/results|files|videos)\//i.test(raw)) return;
    if (!urls.includes(raw)) urls.push(raw);
  };
  const visit = (value: unknown, key = '') => {
    if (!value) return;
    if (typeof value === 'string') {
      if (/url|uri|output|image|video|result/i.test(key) || /^https?:\/\//i.test(value) || /^\/api\//i.test(value) || /^\/v1\//i.test(value)) push(value);
      return;
    }
    if (Array.isArray(value)) {
      value.forEach(item => visit(item, key));
      return;
    }
    if (isRecord(value)) {
      const inline = value.inlineData || value.inline_data;
      if (inline) visit(inline, 'inlineData');
      Object.entries(value).forEach(([itemKey, item]) => {
        if (/url|uri|output|image|video|result/i.test(itemKey)) visit(item, itemKey);
        else if (isRecord(item) || Array.isArray(item)) visit(item, itemKey);
      });
    }
  };
  visit(task.resultUrlsJson, 'resultUrlsJson');
  visit(task.resultJson, 'resultJson');
  visit(task.responseJson, 'responseJson');
  return urls;
}

function isTerminalStatus(status: string) {
  return ['SUCCESS', 'FAILED', 'REFUNDED', 'CANCELLED', 'TIMEOUT', 'MANUAL_REVIEW'].includes(status);
}

function isTransientGenerationFailureMessage(message: unknown) {
  return /stream disconnected before completion|HTTP\s*502|internal_server_error|server_error|bad gateway|gateway timeout|upstream|timeout|timed out|failed to fetch|network|502|503|504|ECONN|ETIMEDOUT|EAI_AGAIN|socket hang up|connection reset|premature close/i.test(String(message || ''));
}

async function markGenerationSubmitStarted(taskId: string, startedAt: Date) {
  await prisma.generationTask.update({
    where: { id: taskId },
    data: {
      status: 'RUNNING',
      startedAt,
    },
  });
}

function startGenerationSubmitHeartbeat(taskId: string) {
  const intervalMs = Math.max(10_000, Math.min(60_000, Math.floor(generationStaleTaskWindowMs() / 3)));
  const timer = setInterval(() => {
    prisma.generationTask.updateMany({
      where: {
        id: taskId,
        status: { in: ['CREATED', 'PENDING', 'RUNNING'] },
      },
      data: { updatedAt: new Date() },
    }).catch(err => {
      console.warn(`[generation-submit] heartbeat for task ${taskId} failed:`, err instanceof Error ? err.message : err);
    });
  }, intervalMs);
  timer.unref?.();
  return () => clearInterval(timer);
}

function isFreshGenerationSubmit(task: Pick<RuntimeGenerationTask, 'status' | 'updatedAt'>) {
  if (!['CREATED', 'PENDING', 'RUNNING'].includes(task.status)) return false;
  return Date.now() - task.updatedAt.getTime() < generationStaleTaskWindowMs();
}

function generationStaleTaskWindowMs() {
  return Math.max(1, config.generationStaleTaskMinutes) * 60_000;
}

function estimateTaskCostInput(body: z.infer<typeof taskSchema>) {
  const quantity = numberParam(body.params, ['n', 'quantity'], 1);
  const durationSeconds = numberParam(body.params, ['durationSeconds', 'duration', 'seconds'], 0);
  if (body.type !== 'LLM') {
    return {
      quantity,
      durationSeconds,
      inputTokens: 0,
      outputTokens: 0,
      size: stringParam(body.params, ['size']),
      resolution: stringParam(body.params, ['resolution', 'requestedResolution', 'quality']),
      imageSize: stringParam(body.params, ['imageSize', 'requestedPixelSize']),
      params: body.params,
    };
  }
  const inputTokens = numberParam(body.params, ['inputTokens', 'promptTokens'], estimateTextTokens(body.prompt));
  const outputTokens = numberParam(body.params, ['outputTokens', 'completionTokens', 'maxOutputTokens', 'max_tokens'], 4096);
  return { quantity: 1, durationSeconds: 0, inputTokens, outputTokens };
}

function stringParam(params: Record<string, unknown>, keys: string[]) {
  for (const key of keys) {
    const value = params[key];
    if (typeof value === 'string' && value.trim()) return value;
    if (typeof value === 'number' && Number.isFinite(value)) return String(value);
  }
  return undefined;
}

function numberParam(params: Record<string, unknown>, keys: string[], fallback: number) {
  for (const key of keys) {
    const value = params[key];
    const numberValue = typeof value === 'number' ? value : typeof value === 'string' && value.trim() ? Number(value) : NaN;
    if (Number.isFinite(numberValue) && numberValue >= 0) return numberValue;
  }
  return fallback;
}

async function refundGenerationTask(tx: Prisma.TransactionClient, input: {
  taskId: string;
  source: GenerationRefundSource;
  reason: string;
  operatorId?: string;
}) {
  const task = await tx.generationTask.findUnique({
    where: { id: input.taskId },
    include: { model: true, provider: true },
  });
  if (!task) fail(404, '生成任务不存在', 'GENERATION_TASK_NOT_FOUND');
  if (task.refundStatus === 'SUCCESS' || task.refundCredits > 0) {
    const wallet = await tx.wallet.findUnique({ where: { userId: task.userId } });
    if (!wallet) fail(404, '钱包不存在', 'WALLET_NOT_FOUND');
    return { task, refundedCredits: 0, balance: wallet.balance, alreadyRefunded: true };
  }
  const claimed = await tx.generationTask.updateMany({
    where: { id: task.id, refundStatus: { not: 'SUCCESS' }, refundCredits: 0 },
    data: { refundStatus: 'PROCESSING', refundReason: input.reason },
  });
  if (claimed.count !== 1) {
    const [currentTask, wallet] = await Promise.all([
      tx.generationTask.findUnique({ where: { id: task.id }, include: { model: true, provider: true, refunds: true } }),
      tx.wallet.findUnique({ where: { userId: task.userId } }),
    ]);
    if (!wallet) fail(404, '钱包不存在', 'WALLET_NOT_FOUND');
    return { task: currentTask || task, refundedCredits: 0, balance: wallet.balance, alreadyRefunded: true };
  }

  const amount = Math.max(0, task.chargedCredits);
  const refund = await tx.generationRefund.create({
    data: {
      taskId: task.id,
      userId: task.userId,
      amount,
      status: 'PENDING',
      source: input.source,
      reason: input.reason,
      operatorId: input.operatorId,
    },
  });

  if (amount <= 0) {
    const wallet = await tx.wallet.findUnique({ where: { userId: task.userId } });
    if (!wallet) fail(404, '钱包不存在', 'WALLET_NOT_FOUND');
    const updatedTask = await tx.generationTask.update({
      where: { id: task.id },
      data: { refundStatus: 'SUCCESS', refundReason: input.reason, refundedAt: new Date() },
      include: { model: true, provider: true, refunds: true },
    });
    await tx.generationRefund.update({ where: { id: refund.id }, data: { status: 'SUCCESS', processedAt: new Date() } });
    return { task: updatedTask, refund, refundedCredits: 0, balance: wallet.balance, alreadyRefunded: false };
  }

  const walletChange = await applyWalletDelta(tx, { userId: task.userId, delta: amount });
  await tx.walletLog.create({
    data: {
      userId: task.userId,
      type: 'REFUND',
      amount,
      balanceBefore: walletChange.balanceBefore,
      balanceAfter: walletChange.balanceAfter,
      relatedType: 'GENERATION_TASK',
      relatedId: task.id,
      remark: `${task.model.displayName} 生成任务退款`,
    },
  });
  const processedRefund = await tx.generationRefund.update({
    where: { id: refund.id },
    data: { status: 'SUCCESS', processedAt: new Date() },
  });
  const updatedTask = await tx.generationTask.update({
    where: { id: task.id },
    data: {
      status: 'REFUNDED',
      refundCredits: amount,
      refundStatus: 'SUCCESS',
      refundReason: input.reason,
      refundedAt: new Date(),
    },
    include: { model: true, provider: true, refunds: true },
  });
  return { task: updatedTask, refund: processedRefund, refundedCredits: amount, balance: walletChange.balanceAfter, alreadyRefunded: false };
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value && typeof value === 'object' && !Array.isArray(value));
}

export default router;
