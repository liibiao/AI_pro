aiyunzhi panic diagnostic
