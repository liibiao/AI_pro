#!/usr/bin/env bash
set +H
set -euo pipefail

PKG="canvas-storyboard-ref-remove-hover-fix-20260604232736"
ARCHIVE="${1:-/tmp/${PKG}.tar.gz}"
MIRROR_TARGET="${2:-${MIRROR_TARGET:-/home/ubuntu/漫剧创作库}}"
WEB_ROOT="${WEB_ROOT:-/var/www/ai-admin}"
WORKBENCH_DIR="${WORKBENCH_DIR:-$WEB_ROOT/workbench-web}"
PM2_USER="${PM2_USER:-ubuntu}"
STAMP="$(date +%Y%m%d%H%M%S)"
WORK_DIR="$(mktemp -d /tmp/${PKG}.XXXXXX)"
BACKUP_DIR="$MIRROR_TARGET/.deploy-backups/${PKG}-${STAMP}"

log(){ printf '[deploy] %s\n' "$*"; }
fail(){ printf '[deploy] ERROR: %s\n' "$*" >&2; exit 1; }
run_sudo(){
  "$@" && return 0
  local status=$?
  if [ "$(id -u)" -eq 0 ] || [ "${DEPLOY_USE_SUDO:-auto}" = "never" ] || [ "${1:-}" = "test" ]; then
    return "$status"
  fi
  if command -v sudo >/dev/null 2>&1; then
    sudo -n "$@"
  else
    return "$status"
  fi
}
backup_file(){
  local dest="$1"
  run_sudo test -f "$dest" || return 0
  local rel="${dest#/}"
  local backup="$BACKUP_DIR/$rel"
  run_sudo mkdir -p "$(dirname "$backup")"
  run_sudo cp -p "$dest" "$backup"
}
install_required(){
  local src="$1" dest="$2" label="$3"
  [ -f "$src" ] || fail "$label missing in package: $src"
  run_sudo test -d "$(dirname "$dest")" || fail "$label destination directory not found: $(dirname "$dest")"
  backup_file "$dest"
  run_sudo cp -p "$src" "$dest"
  log "installed $dest"
}
install_optional_existing(){
  local src="$1" dest="$2" label="$3"
  [ -f "$src" ] || fail "$label missing in package: $src"
  if ! run_sudo test -f "$dest"; then
    log "skip $label, target not found: $dest"
    return 0
  fi
  backup_file "$dest"
  run_sudo cp -p "$src" "$dest"
  log "installed $dest"
}
verify_canvas_markers(){
  local file="$1"
  grep -Fq "const GENERATION_TASK_SUBMIT_TIMEOUT_MS=600000" "$file"
  grep -Fq "const GENERATION_TASK_RECOVERY_MAX_MS=600000" "$file"
  grep -Fq "X-Upstream-Timeout-Ms" "$file"
  grep -Fq "timeoutMs:GENERATION_TASK_SUBMIT_TIMEOUT_MS" "$file"
  grep -Fq "waitForNodeCosUpload(id,{timeout=300000" "$file"
  grep -Fq "connectMultiSelectedNodesToTarget" "$file"
  grep -Fq "textPrompt:{cat:'input',name:'文本节点'" "$file"
  grep -Fq ".node.node-type-shotStoryboard .storygrid-ref-area .vn2-ref-chip-close{right:3px!important;top:3px!important}" "$file"
  grep -Fq ".node.node-type-shotStoryboard .storygrid-ref-area .vn2-ref-add-chip,.node.node-type-shotStoryboard .storygrid-ref-area .vn2-ref-chip{flex:0 0 58px!important;width:58px!important;height:66px!important;min-height:66px!important;margin:0!important;padding:0!important;display:block!important;border-radius:11px!important;overflow:visible!important;opacity:1!important;transform:none!important}" "$file"
  grep -Fq "function shouldSuppressPromptZoomChipHoverPreview" "$file"
  grep -Fq "if(shouldSuppressPromptZoomChipHoverPreview(chip)){hidePromptZoomChipPreview(nodeId,group);return;}" "$file"
}
verify_service_markers(){
  local file="$1"
  grep -Fq "const GENERATION_TASK_SUBMIT_TIMEOUT_MS=600000" "$file"
  grep -Fq "const GENERATION_TASK_RECOVERY_MAX_MS=600000" "$file"
  grep -Fq "X-Upstream-Timeout-Ms" "$file"
  grep -Fq "timeoutMs:GENERATION_TASK_SUBMIT_TIMEOUT_MS" "$file"
}
verify_python_backend_markers(){
  local file="$1"
  grep -Fq "timeout=600" "$file"
}
verify_runninghub_markers(){
  local file="$1"
  grep -Fq "urlopen(req, timeout=600)" "$file"
}
verify_canvas_markers_sudo(){
  local file="$1"
  run_sudo grep -Fq "const GENERATION_TASK_SUBMIT_TIMEOUT_MS=600000" "$file"
  run_sudo grep -Fq "const GENERATION_TASK_RECOVERY_MAX_MS=600000" "$file"
  run_sudo grep -Fq "X-Upstream-Timeout-Ms" "$file"
  run_sudo grep -Fq "timeoutMs:GENERATION_TASK_SUBMIT_TIMEOUT_MS" "$file"
  run_sudo grep -Fq "waitForNodeCosUpload(id,{timeout=300000" "$file"
  run_sudo grep -Fq "connectMultiSelectedNodesToTarget" "$file"
  run_sudo grep -Fq "textPrompt:{cat:'input',name:'文本节点'" "$file"
  run_sudo grep -Fq ".node.node-type-shotStoryboard .storygrid-ref-area .vn2-ref-chip-close{right:3px!important;top:3px!important}" "$file"
  run_sudo grep -Fq ".node.node-type-shotStoryboard .storygrid-ref-area .vn2-ref-add-chip,.node.node-type-shotStoryboard .storygrid-ref-area .vn2-ref-chip{flex:0 0 58px!important;width:58px!important;height:66px!important;min-height:66px!important;margin:0!important;padding:0!important;display:block!important;border-radius:11px!important;overflow:visible!important;opacity:1!important;transform:none!important}" "$file"
  run_sudo grep -Fq "function shouldSuppressPromptZoomChipHoverPreview" "$file"
  run_sudo grep -Fq "if(shouldSuppressPromptZoomChipHoverPreview(chip)){hidePromptZoomChipPreview(nodeId,group);return;}" "$file"
}
verify_service_markers_sudo(){
  local file="$1"
  run_sudo grep -Fq "const GENERATION_TASK_SUBMIT_TIMEOUT_MS=600000" "$file"
  run_sudo grep -Fq "const GENERATION_TASK_RECOVERY_MAX_MS=600000" "$file"
  run_sudo grep -Fq "X-Upstream-Timeout-Ms" "$file"
  run_sudo grep -Fq "timeoutMs:GENERATION_TASK_SUBMIT_TIMEOUT_MS" "$file"
}
verify_python_backend_markers_sudo(){
  local file="$1"
  run_sudo grep -Fq "timeout=600" "$file"
}
verify_runninghub_markers_sudo(){
  local file="$1"
  run_sudo grep -Fq "urlopen(req, timeout=600)" "$file"
}
pm2_run(){
  if [ "$(id -u)" -eq 0 ] && [ -n "$PM2_USER" ] && command -v sudo >/dev/null 2>&1 && id "$PM2_USER" >/dev/null 2>&1; then
    sudo -n -u "$PM2_USER" env PM2_HOME="/home/$PM2_USER/.pm2" pm2 "$@"
    return $?
  fi
  if command -v pm2 >/dev/null 2>&1; then
    pm2 "$@"
    return $?
  fi
  if command -v sudo >/dev/null 2>&1 && id "$PM2_USER" >/dev/null 2>&1; then
    sudo -n -u "$PM2_USER" env PM2_HOME="/home/$PM2_USER/.pm2" pm2 "$@"
    return $?
  fi
  return 127
}
pm2_restart_if_exists(){
  local name="$1"
  pm2_run show "$name" >/dev/null 2>&1 || return 1
  log "restart pm2: $name"
  pm2_run restart "$name" --update-env >/dev/null
}

cleanup(){ rm -rf "$WORK_DIR"; }
trap cleanup EXIT

[ -f "$ARCHIVE" ] || fail "archive not found: $ARCHIVE"
log "extract $ARCHIVE"
tar --no-same-owner -xzf "$ARCHIVE" -C "$WORK_DIR"
SRC="$WORK_DIR/$PKG"
[ -d "$SRC" ] || fail "package root not found: $SRC"

log "verify package markers"
verify_canvas_markers "$SRC/workbench-web/image-studio-canvas-next.html"
verify_canvas_markers "$SRC/tools/workbench-web/image-studio-canvas-next.html"
verify_service_markers "$SRC/workbench-web/canvas-next/generation-service.js"
verify_service_markers "$SRC/tools/workbench-web/canvas-next/generation-service.js"
verify_python_backend_markers "$SRC/tools/image_studio_backend.py"
verify_python_backend_markers "$SRC/smart-vision/services/workbench/image_studio_backend.py"
verify_runninghub_markers "$SRC/tools/runninghub_client.py"

log "backup dir: $BACKUP_DIR"
run_sudo mkdir -p "$BACKUP_DIR"

log "install public workbench: $WORKBENCH_DIR"
install_required "$SRC/workbench-web/image-studio-canvas-next.html" "$WORKBENCH_DIR/image-studio-canvas-next.html" "public canvas"
install_optional_existing "$SRC/workbench-web/canvas-next/generation-service.js" "$WORKBENCH_DIR/canvas-next/generation-service.js" "public generation service"

if [ -d "$MIRROR_TARGET/tools/workbench-web" ]; then
  log "install mirror workbench: $MIRROR_TARGET/tools/workbench-web"
  install_optional_existing "$SRC/tools/workbench-web/image-studio-canvas-next.html" "$MIRROR_TARGET/tools/workbench-web/image-studio-canvas-next.html" "mirror canvas"
  install_optional_existing "$SRC/tools/workbench-web/canvas-next/generation-service.js" "$MIRROR_TARGET/tools/workbench-web/canvas-next/generation-service.js" "mirror generation service"
else
  log "mirror workbench skipped, not found: $MIRROR_TARGET/tools/workbench-web"
fi

install_optional_existing "$SRC/tools/image_studio_backend.py" "$MIRROR_TARGET/tools/image_studio_backend.py" "mirror image backend"
install_optional_existing "$SRC/tools/runninghub_client.py" "$MIRROR_TARGET/tools/runninghub_client.py" "mirror RunningHub client"
install_optional_existing "$SRC/smart-vision/services/workbench/image_studio_backend.py" "$MIRROR_TARGET/smart-vision/services/workbench/image_studio_backend.py" "smart image backend"

log "verify installed markers"
verify_canvas_markers_sudo "$WORKBENCH_DIR/image-studio-canvas-next.html"
if run_sudo test -f "$WORKBENCH_DIR/canvas-next/generation-service.js"; then
  verify_service_markers_sudo "$WORKBENCH_DIR/canvas-next/generation-service.js"
fi
if run_sudo test -f "$MIRROR_TARGET/tools/workbench-web/image-studio-canvas-next.html"; then
  verify_canvas_markers_sudo "$MIRROR_TARGET/tools/workbench-web/image-studio-canvas-next.html"
fi
if run_sudo test -f "$MIRROR_TARGET/tools/workbench-web/canvas-next/generation-service.js"; then
  verify_service_markers_sudo "$MIRROR_TARGET/tools/workbench-web/canvas-next/generation-service.js"
fi
if run_sudo test -f "$MIRROR_TARGET/tools/image_studio_backend.py"; then
  verify_python_backend_markers_sudo "$MIRROR_TARGET/tools/image_studio_backend.py"
fi
if run_sudo test -f "$MIRROR_TARGET/tools/runninghub_client.py"; then
  verify_runninghub_markers_sudo "$MIRROR_TARGET/tools/runninghub_client.py"
fi
if run_sudo test -f "$MIRROR_TARGET/smart-vision/services/workbench/image_studio_backend.py"; then
  verify_python_backend_markers_sudo "$MIRROR_TARGET/smart-vision/services/workbench/image_studio_backend.py"
fi

if command -v python3 >/dev/null 2>&1; then
  PY_FILES=()
  [ -f "$MIRROR_TARGET/tools/image_studio_backend.py" ] && PY_FILES+=("$MIRROR_TARGET/tools/image_studio_backend.py")
  [ -f "$MIRROR_TARGET/tools/runninghub_client.py" ] && PY_FILES+=("$MIRROR_TARGET/tools/runninghub_client.py")
  [ -f "$MIRROR_TARGET/smart-vision/services/workbench/image_studio_backend.py" ] && PY_FILES+=("$MIRROR_TARGET/smart-vision/services/workbench/image_studio_backend.py")
  if [ "${#PY_FILES[@]}" -gt 0 ]; then
    python3 -m py_compile "${PY_FILES[@]}" >/dev/null 2>&1 || log "python compile check skipped/failed"
  fi
fi

RESTARTED=0
for name in ai-admin-api workbench-server smart-vision-workbench; do
  if pm2_restart_if_exists "$name"; then
    RESTARTED=1
  fi
done
if [ "$RESTARTED" -eq 0 ]; then
  log "pm2 restart skipped; restart the backend/workbench service manually if it is long-running"
fi

log "done"
echo "backup: $BACKUP_DIR"
echo "Hard-refresh the canvas page after deploy."
