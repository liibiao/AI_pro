const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

function trim(value) {
  if (typeof value === 'string') return value.length > 500 ? `${value.slice(0, 500)}...[${value.length}]` : value;
  if (Array.isArray(value)) return value.map(trim);
  if (value && typeof value === 'object') {
    return Object.fromEntries(Object.entries(value).map(([key, child]) => [key, trim(child)]));
  }
  return value;
}

function pickTask(task) {
  const params = task.paramsJson && typeof task.paramsJson === 'object' ? task.paramsJson : {};
  const request = task.requestJson && typeof task.requestJson === 'object' ? task.requestJson : {};
  const result = task.resultJson && typeof task.resultJson === 'object' ? task.resultJson : {};
  const response = task.responseJson && typeof task.responseJson === 'object' ? task.responseJson : {};
  return {
    id: task.id,
    createdAt: task.createdAt,
    status: task.status,
    channelKey: task.channelKey,
    mode: task.mode,
    modelName: task.model?.name,
    modelDisplayName: task.model?.displayName,
    modelKey: task.model?.modelKey,
    modelAdapter: task.model?.adapter,
    modelEndpointPath: task.model?.endpointPath,
    providerKey: task.provider?.providerKey,
    providerName: task.provider?.name,
    providerAdapter: task.provider?.adapter,
    errorCode: task.errorCode,
    errorMessage: trim(task.errorMessage),
    paramsCore: {
      model: params.model,
      modelNick: params.modelNick,
      adapter: params.adapter,
      protocolAdapter: params.protocol?.adapter,
      endpointPath: params.endpointPath || params.protocol?.endpointPath,
      size: params.size,
      resolution: params.resolution,
      requestedResolution: params.requestedResolution,
      imageSize: params.imageSize,
      image_size: params.image_size,
      requestedPixelSize: params.requestedPixelSize,
      pixelSize: params.pixelSize,
      aspectRatio: params.aspectRatio,
      response_format: params.response_format,
      responseType: params.responseType || params.response_type,
    },
    requestCore: {
      model: request.model,
      size: request.size,
      n: request.n,
      response_format: request.response_format,
      hasImages: Array.isArray(request.images) || Array.isArray(request.image),
      image_count: request.image_count,
    },
    resultCore: {
      url: result.url,
      outputs: Array.isArray(result.outputs) ? result.outputs.slice(0, 2) : result.outputs,
      width: result.width || result.imageWidth || result.image_width,
      height: result.height || result.imageHeight || result.image_height,
      storage: result.storage,
      temporaryUrls: result.temporaryUrls,
      sourceUrls: result.sourceUrls,
    },
    responseCore: trim(response),
    resultUrlsJson: trim(task.resultUrlsJson),
  };
}

(async () => {
  const tasks = await prisma.generationTask.findMany({
    where: {
      type: 'IMAGE',
      OR: [
        { channelKey: 'model_gtp-2-max_mqsufujl' },
        { channelKey: 'model_gpt-2-plus' },
        { model: { is: { name: { contains: 'gpt-image-2-plus' } } } },
        { model: { is: { displayName: { contains: '优化plus' } } } },
        { paramsJson: { path: ['model'], equals: 'gpt-image-2-plus' } },
        { paramsJson: { path: ['modelNick'], string_contains: '优化plus' } },
      ],
    },
    orderBy: { createdAt: 'desc' },
    take: 30,
    include: { model: true, provider: true },
  });
  console.log(JSON.stringify(tasks.map(pickTask), null, 2));
})()
  .catch(error => {
    console.error(error);
    process.exitCode = 1;
  })
  .finally(async () => prisma.$disconnect());
