#!/usr/bin/env bash
set -euo pipefail

PKG="gpt2-plus-resolution-audit-20260626051404"
ARCHIVE="${1:?archive path required}"
APP_DIR="${APP_DIR:-/var/www/ai-admin/ai-admin-platform/api-server}"
WORK_DIR="$(mktemp -d /tmp/${PKG}.XXXXXX)"
REMOTE_SCRIPT="/tmp/query-gpt2-plus-max-resolution.cjs"

cleanup(){
  rm -rf "$WORK_DIR"
  rm -f "$REMOTE_SCRIPT"
}
trap cleanup EXIT

tar --no-same-owner -xzf "$ARCHIVE" -C "$WORK_DIR"
[ -f "$WORK_DIR/$PKG/payload/query-gpt2-plus-max-resolution.cjs" ] || { echo "missing query script" >&2; exit 1; }
install -m 0600 "$WORK_DIR/$PKG/payload/query-gpt2-plus-max-resolution.cjs" "$REMOTE_SCRIPT"
cd "$APP_DIR"
node "$REMOTE_SCRIPT"
