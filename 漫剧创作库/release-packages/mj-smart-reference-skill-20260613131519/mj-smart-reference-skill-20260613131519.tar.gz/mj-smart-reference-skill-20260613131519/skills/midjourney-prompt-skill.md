---
name: midjourney-prompt-skill
description: Convert user natural-language image descriptions into faithful, high-quality English Midjourney prompts with safe, legal parameters for the currently selected MJ/Niji version. Use when optimizing prompts for Midjourney, MJ, MJ-Niji, RunningHub Midjourney Imagine, or canvas smart Midjourney mode.
---

# midjourney-prompt-skill — Midjourney 智能提示词技能

## 技能定位
把用户输入的自然语言画面描述，转换成适合当前所选 Midjourney / MJ / MJ-Niji 版本的英文复合提示词与合法参数。核心目标是高画质、提示词正确、画面忠于用户原意。

可结合漫剧创作库中的 MJ 提示词库做参考优化，但词库只提供候选表达，不是新的创作指令。所有词库词必须先通过“是否贴合用户自然语言原意”的筛选。

## 不可违背原则
- 用户自然语言提示词是最高优先级的“意图源”。必须先抽取并保留用户明确写下的主体、人物身份、动作、场景、时代、关系、情绪、风格和构图，再做 MJ 优化。
- 不改变用户提示词的大意，不新增会改变主体、人物身份、动作、场景、时代、关系或情绪结果的设定。
- 不为了“更炫”而替换用户指定的风格、物种、性别、年龄、服装、道具、地点或构图。
- 只能补全镜头、光影、材质、画质、构图、色彩和 Midjourney 参数这类执行信息。
- 用户描述含糊时，选择最保守的视觉补全；不确定的信息写成中性表达。
- 参考图、@资源、词库候选词和风格词都低于用户自然语言优先级；如果参考图/资源与用户文字冲突，必须以用户文字为准，并在 `warnings` 中说明已降低冲突参考的权重。
- 词库候选词只允许用于把用户已经表达或强烈暗示的内容翻译成更适合 MJ 的画质、镜头、风格、光影、材质和参数语言；不能凭词库新增用户没写的剧情、角色身份、动作、地点或关键道具。
- 不允许根据参考图自行替换用户文字中的人物、地点、动作或剧情。参考图只能用于保持指定角色/物体/风格/构图，不能重新定义用户想画什么。
- 图生图富文本里的 `参考图1`、`参考图2` 等占位符代表用户通过 @资源 插入的图片位置，必须保留它们在句子中的语义角色。例如“参考图2 骑在 参考图1 的背上”应理解为“参考图2里的主体骑在参考图1里的主体/生物/物体背上”，不能写成 unspecified subject/mount。
- 图生图智能模式必须强参考一致性：参考图中的人物形象、五官样貌、发型、服装、服装颜色、体型比例、轮廓和整体画风都要尽量一模一样保留。除非用户明确要求改造，不得换脸、换发型、换衣服、改变年龄气质、改变物种或重新设计角色。
- 真实图片 URL 由画布程序按参考图职责拼到最终 MJ prompt：构图/场景/姿势/道具图放在 prompt 最前面，角色图放到 `--cref`，风格图放到 `--sref`；skill 不要伪造 URL，只要在英文 prompt 中保留 reference image N 的角色关系。
- 输出必须是合法 Midjourney 语法；参数只放在末尾，不夹在主体描述中间。
- 用户在画布中已经选择的模型版本、画幅比例和确定参数是硬约束，不能被 skill 改写；例如用户选择 V8.1 时必须使用 `--v 8.1`，不能改回 `--v 7`。
- 图生图的参考图权重 `--iw` 由画布智能模式控制：智能图生图默认强一致性 `--iw 3`；如果用户手动改了 IW，就以用户当前选择为准。不要输出与当前选择冲突的 `--iw`。
- 避免堆砌互相冲突的画质词，优先清晰、主体明确、光影干净、细节可读。

## 输出结构
每次输出 JSON：
```json
{
  "prompt": "English Midjourney prompt without image URLs",
  "params": "--ar 16:9 --v 8.1 --style raw --s 100 --c 6 --q 4 --hd",
  "aspectRatio": "16:9",
  "qualityProfile": "high",
  "fidelityCheck": "one short Chinese sentence explaining why the result preserves the user intent",
  "warnings": []
}
```

## 图生图参考图职责识别
当画布传入参考图、@资源或“参考图N”占位符时，必须先判断每张图的职责，再决定 `--iw` / `--cref` / `--sref` 的组合。不要把所有参考图都只当垫图。

### 角色一致：使用 `--cref`
触发意图包括但不限于：
- 中文：这个人、这位、同一个人、同一角色、主角、女主、男主、角色、人物、脸不变、长相不变、样貌一致、五官一致、眉眼、眼睛、瞳色、鼻子、嘴唇、脸型、发型、发色、刘海、发饰、头冠、耳环、疤痕、纹身、妆容、肤色、年龄感、气质、身高、体型、身材比例、轮廓、姿态习惯、身份识别点、人物形象、不要换脸、不能变脸、保持原人物、完全一致、一模一样。
- English: same person, same character, character consistency, preserve identity, exact face, facial features, hairstyle, body shape, outfit, costume, silhouette, no face change, identical character.

默认策略：`--cref [角色图URL] --cw 90-100`，并在英文 prompt 中写明 preserve the exact same character identity, facial features, hairstyle, outfit, clothing colors, body proportions and silhouette。

如果用户明确要求换衣服、改服装、换战甲、换校服、换古装、换发型、重新造型：把 `--cw` 降到 `60-80`，英文 prompt 必须写成 preserve the same face / identity / body proportions, but change only the requested outfit or styling。

### 风格一致：使用 `--sref`
触发意图包括但不限于：
- 中文：画风、风格、视觉风格、色调、调性、质感、笔触、上色、渲染、光影、氛围、电影感、胶片感、国漫、日漫、二次元、赛璐璐、厚涂、水墨、油画、水彩、3D、CG、写实、超写实、概念设计、赛博朋克、仙侠、暗黑、哥特、废土、蒸汽朋克、低饱和、高级灰、霓虹、柔光、硬光、同一套视觉、系列统一、保持画面风格、漫剧风格。
- English: same style, visual style, art style, color grading, tone, texture, rendering style, brushwork, lighting style, cinematic look, anime style, donghua style, concept art style.

默认策略：`--sref [风格图URL] --sw 120-250`。轻度参考用 `--sw 60-120`；用户要求“完全按这个画风”可用 `--sw 250-400`，但不能让风格覆盖用户内容。

### 构图 / 场景 / 姿势 / 道具：URL 前置 + `--iw`
触发意图包括但不限于：
- 中文：参考构图、构图一样、布局、画面结构、站位、位置关系、前景、中景、后景、景别、机位、视角、角度、镜头、近景、特写、远景、俯拍、仰拍、侧面、背面、正面、鸟瞰、广角、超广角、姿势、动作、坐姿、站姿、骑在、趴在、抱着、拿着、背着、站在中间、放在背景里、场景一致、建筑一致、空间一致、房间、街道、广场、森林、宫殿、废墟、道具、武器、坐骑、怪兽、车辆、机甲、宠物、环境结构。
- English: composition, layout, pose, posture, camera angle, shot size, framing, scene structure, environment, background, prop, object, mount, creature, vehicle, architecture, spatial relationship.

默认策略：把对应图片 URL 放在 MJ prompt 最前面，使用当前画布 `--iw`。只借构图时 `--iw 1-1.5`，强复刻场景 / 姿势时 `--iw 2-3`。如果用户手动设置 IW，不能覆盖。

### @资源语义关系必须保留
- `参考图A / @图A 骑在 参考图B / @图B 背上` → the character or subject from reference image A riding on the back of the creature, mount, or object from reference image B。
- `参考图A 穿着 参考图B 的衣服` → the same person from reference image A wearing the outfit from reference image B；A 用 `--cref`，B 作为构图/服装参考，`--cw 60-75`。
- `参考图A 放到 参考图B 场景里` → the same character from reference image A placed inside the environment from reference image B；A 用 `--cref`，B 用 URL 前置 + `--iw`。
- `参考图A 按 参考图B 的画风生成` → the subject from reference image A rendered in the visual style, color palette and lighting of reference image B；A 可用 `--cref`，B 用 `--sref`。
- `参考参考图A 的姿势，让参考图B 做这个动作` → the character from reference image B performing the pose/action shown in reference image A；A 用 URL 前置 + `--iw 1.5-2`，B 用 `--cref`。

### 组合优先级
多意图同时出现时按顺序处理：
1. 角色身份锁定：`--cref`
2. 用户明确关系：英文 prompt 写清参考图之间的语义关系
3. 场景 / 构图 / 姿势锁定：URL 前置 + `--iw`
4. 风格锁定：`--sref`
5. 系列稳定：可保留用户已有 `--seed`
6. 高画质参数：保留画布当前模型、比例、Q、RAW/HD/Turbo 设定

### 默认命令策略
- 普通参考图生图且用户未说明用途：先按构图/场景/姿势参考处理，图片 URL 前置 + 当前 `--iw`。
- 文本出现“同一个人 / 角色一致 / 脸发型服装不变 / 形象一致”：额外使用 `--cref`；默认 `--cw 90-100`。
- 文本出现“换衣服 / 换造型 / 改发型”：仍使用 `--cref` 锁身份，但 `--cw 60-80`，只允许改变用户明确要求变化的部分。
- 文本出现“画风 / 色调 / 质感 / 光影 / 漫剧风格 / 系列统一”：使用 `--sref --sw 120-250`，强风格参考可到 `250-400`。
- 文本出现“参考构图 / 姿势 / 动作 / 场景 / 背景 / 道具 / 坐骑 / 位置关系”：图片 URL 前置 + 当前 `--iw`；智能模式默认高一致性 `--iw 3`，用户手动修改时必须服从用户值。
- 一张图可同时承担多个职责：例如角色参考图既要保持人物又要沿用姿势，可同时 URL 前置并加入 `--cref`。

## 提示词结构
英文 prompt 建议按以下顺序组织：
1. 主体与动作：用户明确写了什么，就保留什么。
2. 场景与时间：只补用户暗示的空间、天气、时间、时代。
3. 构图与镜头：cinematic composition / close-up / wide shot / overhead 等，按用户描述匹配。
4. 光影与色彩：soft diffused light / dramatic rim light / golden hour / moody low key 等。
5. 材质与细节：fabric texture, skin detail, environmental detail, clean edges 等。
6. 画质稳定项：high detail, sharp focus, clean image, professional color grading。

## 参数选择
- 模型版本参数必须来自画布当前选择：`--v 8.1` / `--v 7` / `--niji 7` 等，不能自行降级或改写。
- 画质优先：当前所选模型版本支持 Q4 时必须优先 `--q 4`，包括 `--v 7`、`--v 8.1`、`--niji 7` 等；不支持 Q4 的旧版本才回退 `--q 2`。
- 写实、电影、产品、角色、建筑、封面：优先 `--style raw`
- 动漫 / 漫剧 / 二次元明确需求：只有用户或所选模型明确是 Niji 时才使用 `--niji`，否则保持当前所选 MJ 版本。
- 宽幅电影、场景、群像、横版海报：`--ar 16:9`
- 竖版封面、手机海报、全身角色、短视频首图：`--ar 9:16`
- 方形头像、单物件、Logo、图标、社媒方图：`--ar 1:1`
- 人物半身、商品 KV、角色设定：可用 `--ar 3:4` 或 `--ar 4:5`
- 超宽场景、横向环境概念：可用 `--ar 21:9`
- 图生图强参考一致性默认：`--s 0`、`--c 0`、`--iw 3`，并在英文 prompt 中写明 preserve the exact same character identity, facial features, hairstyle, outfit, clothing colors, body proportions, silhouette and overall visual style from the reference image(s)。

## 负向处理
Midjourney 可用 `--no`，但只在必要时添加：
- 文字、Logo、水印会影响画面：`--no text, watermark, logo`
- 用户要求纯净主体：`--no extra people, duplicate limbs`
- 不要写过长负面列表；负面参数必须服务于画面稳定。

## 自检
输出前检查：
- 英文 prompt 是否仍能一眼看出用户原始描述。
- 是否添加了会改变故事或主体身份的新元素。
- 参考图或词库词是否抢走了用户自然语言的主体含义；如果有冲突，删除冲突补充。
- `fidelityCheck` 必须明确说明保留了哪些用户原始要素，例如主体、动作、场景、风格或构图。
- 参数是否只出现一次，是否含用户当前选择的 `--ar` 与模型版本。
- 提示词是否能直接提交给 Midjourney Imagine。
